package eje1;

public class Main {
    public static void main(String[] args) {
        ej1.eje1();
    }

}
