package eje2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ej2 {

    static File archivo = new File("./src/eje2/agenda.txt");
    static Scanner sc = new Scanner(System.in);

    static ArrayList<String> listaNombres = new ArrayList<>();
    static ArrayList<Integer> listaTelefonos = new ArrayList<>();

    public static void añadirAgenda() {


        System.out.println("Dime el nombre a registrar");
        String nombre = sc.next();

        boolean si = true;

        while (si) {
            try {
                System.out.println("Dime el tlf a registrar");
                int telefono = sc.nextInt();
                comprobar(telefono);
                listaTelefonos.add(telefono);
                listaNombres.add(nombre);
                si = false;
                escribir();
            } catch (NumeroNegativo e) {
                System.out.println(e.getMessage());
                si = true;
            }
        }
    }

    private static void comprobar(int telefono) {
        if (telefono < 0) {
            throw new NumeroNegativo("El número no puede ser negativo");
        }
    }

    public static void escribir() {
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(archivo,true))) {
            for (int i = 0; i < listaNombres.size(); i++) {
                dos.writeUTF(listaNombres.get(i) + listaTelefonos.get(i));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void enseñarAgenda() {

        try (DataInputStream dis = new DataInputStream(new FileInputStream(archivo))) {
            while (true) {
                System.out.println(dis.readUTF());
            }
        } catch (EOFException e) {
            System.out.println("Fin de archivo");
        } catch (StreamCorruptedException e) {
            System.out.println();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}