package eje2;

public class NumeroNegativo extends RuntimeException{
    public NumeroNegativo(String message) {
        super(message);
    }
}
